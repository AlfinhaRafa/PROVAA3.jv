import java.util.Scanner;
public class Cadastro implements interfacenew{
    public void cadastro(int login, int senha) {
        login= email;
        senha= senhadeusuario;

    }
    private static void cadastrar(String nomeComleto, String nomeDeUsario, String email, int senha, int repetirsenha) {
    Scan

    }
    public void lista(String produtos){

]
    public void pesquisar(String produtos){


    }



}