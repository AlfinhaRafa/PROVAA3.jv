class Cadastrar {
}